import { Component } from "react";
import LoadingScreen from "../loadingScreen/loadingScreen";
import Header from "../header/header";
import Cookies from "js-cookie";
import withNavigation from "../../utils/withNavigation";

class ShowDetails extends Component {
  requestStatus = {
    progress: "PROGRESS",
    success: "SUCCESS",
    failure: "FAILURE",
  };
  state = {
    urlResult: [],
    urlStatus: this.requestStatus.progress,
  };

  componentDidMount(){
    this.fetchResults();
  }

  fetchResults=async ()=>{
    const url = process.env.REACT_APP_BACKEND_URL;
    const {theatre_id,theatre_name} = this.props.params;
    const options = {
      method: "GET",
      header: {
        Authorization: `Bearer `+Cookies.get("token"),
      }
    }
    const response = await fetch(url+`theatre/${theatre_name}/${theatre_id}`,options);
    if(response.ok) console.log("api triggered")
  }

  getCurrentView = () => {
    const { urlStatus } = this.state;
    switch (urlStatus) {
      case this.requestStatus.progress:
        return <LoadingScreen />;
      case this.requestStatus.success:
        return <h1>Success View</h1>;
      case this.requestStatus.failure:
        return <h1>Failure View</h1>;
       default:
            return <LoadingScreen /> 
    }
  };

  render() {
    return (
      <>
        <Header />
        {this.getCurrentView()}
      </>
    );
  }
}

export default withNavigation(ShowDetails);
